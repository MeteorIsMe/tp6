<?php
namespace app\admin\controller;

use app\admin\controller;

class Index extends Base
{
    public function index()
    {
        return 'admin';
    }

    public function hello($name = 'ThinkPHP6')
    {
        return 'hello,' . $name;
    }
}
